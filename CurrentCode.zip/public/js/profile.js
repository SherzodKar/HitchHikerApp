/*
    Version 1.1: Dynamic display and update functionality added
		Author:	 		Ryan Bump
		Completed On: 	11/3/19

	Version 1.0: Basic display function created
		Author:	 		Ryan Bump
		Completed On: 	10/27/19
*/

window.onload = function() {
    var firebaseConfig = {
        apiKey: "AIzaSyCC5r3rtnror2kB2pR6Jl2jNFiQLX4qZ5M",
        authDomain: "hitchhickerapp.firebaseapp.com",
        databaseURL: "https://hitchhickerapp.firebaseio.com",
        projectId: "hitchhickerapp",
        storageBucket: "",
        messagingSenderId: "206844179483",
        appId: "1:206844179483:web:0d67743e9a9e0628ecf4be"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    var database = firebase.database()

    firebase.auth().onAuthStateChanged(firebaseUser => {
        if(firebaseUser){
            database.ref('AllUsers').child(firebase.auth().currentUser.uid).once('value', e => {
                this.console.log(firebaseUser.email)
                this.console.log("HellO")
                var userInfo = e.val()
                this.console.log(userInfo.firstName, userInfo.lastName)
                document.getElementById("firstName").value = userInfo.firstName;
                document.getElementById("lastName").value = userInfo.lastName;
                document.getElementById("phoneNumber").value = userInfo.phoneNumber;
                document.getElementById("email").value = firebaseUser.email;

                
	            const updateBtn = document.getElementById('updateBtn');
                updateBtn.addEventListener('click', e => {
                    this.console.log("Inside button click")
                    this.console.log(userInfo.firstName)
                    
                    
                    firebase.auth().onAuthStateChanged(firebaseUser => {
                        const txtFirstName = document.getElementById('firstName');
                        const txtLastName = document.getElementById('lastName');
                        const txtPhoneNumber = document.getElementById('phoneNumber');
                        const firstName = txtFirstName.value.toString();
                        const lastName = txtLastName.value.toString();
                        const phoneNumber = txtPhoneNumber.value.toString();
                        if(firebaseUser){
                            var userInfoJSON = {
                                'firstName' : firstName,
                                'lastName' : lastName,
                                'phoneNumber' : phoneNumber,
                                //'authIDNumber' : currentUser.uid
                            }
                            var fireRef = firebase.database().ref('AllUsers').child(firebaseUser.uid);
                            fireRef.push();
                            fireRef.set(userInfoJSON).then(function(){
                                window.location.reload();
                            })
                        }		
                    });
                })
            })
        }
        else {
            window.location = "index.html";
        }
    })
};