/*
    script.js
    version 1.1, Sherzod - added side bar navigation
	version 1.0, Sherzod

	This file is designed to make the home page function.
*/
window.onload = function() {
    var firebaseConfig = {
        apiKey: "AIzaSyCC5r3rtnror2kB2pR6Jl2jNFiQLX4qZ5M",
        authDomain: "hitchhickerapp.firebaseapp.com",
        databaseURL: "https://hitchhickerapp.firebaseio.com",
        projectId: "hitchhickerapp",
        storageBucket: "",
        messagingSenderId: "206844179483",
        appId: "1:206844179483:web:0d67743e9a9e0628ecf4be"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);

    firebase.auth().onAuthStateChanged(firebaseUser => {
        if(firebaseUser){
            $('.hamburger, .menu-inner').on('mouseenter', function(){
                $(this).parent().addClass('expanded');
                menuExpanded = true;
            });

            $('.menu-inner').on('mouseleave', function(){
                menuExpanded = false;
                $(this).parent().removeClass('expanded');
            });
        }
        else {
            window.location = "index.html";
        }
    });
};
